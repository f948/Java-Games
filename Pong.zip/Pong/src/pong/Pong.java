/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pong;


import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class Pong extends Application {
    
     // set up the scene 
    static Canvas canvas = new Canvas(1000, 800);
    static GraphicsContext context = canvas.getGraphicsContext2D();
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root,1000,800);

   static Random rand = new Random();
  
   // create paddle 
    static int paddle1X;
    static int paddle1Y;
    
   // create second paddle 
    static int paddle2X;
    static int paddle2Y;
       
    // create ball 
    static double ballX,ballY,velocityX,velocityY,signX,signY,angle;
    static final int radius=20;
    static double collidePoint;
    static int speed;
    
    static String paddle1Direction="";
    static String paddle2Direction="";
    
    
    
    public static void startGame(){
        
        paddle1X=100;
        paddle1Y=380;
        
        paddle2X=900;
        paddle2Y=380;
        
        angle = Math.random()*20+40;
        
        speed=8;
        
        velocityX=Math.cos(angle)*speed;
        velocityY=Math.sin(angle)*speed;
                                    
        signX = rand.nextInt(2);
        if(signX == 0){
            velocityX=-velocityX;
        }

        signY=rand.nextInt(2);
        if(signY == 0){
            velocityY=-velocityY;
        }
      
        
        ballX=500;
        ballY=400;
        


    }
   
  

    @Override
    public void start(Stage primaryStage) {
       
        startGame();
        
        // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
            if (key.getCode() == KeyCode.W) {
		paddle1Direction ="up";
            }
            
	    if (key.getCode() == KeyCode.S ) {
		paddle1Direction="down";
	    }

            if (key.getCode() == KeyCode.I ) {
		paddle2Direction ="up";
            }
            
	    if (key.getCode() == KeyCode.K ) {
		paddle2Direction="down";
	    }

	});
        
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                
                 // clear the screen
                context.clearRect(0, 0, 1000, 800);

                // draw background
                context.setFill(Color.BLACK);
                context.fillRect(0, 0, 1000, 800);

                // move paddle 
                if(paddle1Direction =="up" && paddle1Y>0){
                    paddle1Y-=20;
                }
                else if(paddle1Direction=="down" && paddle1Y+50<800){
                    paddle1Y+=20;
                }
                
                paddle1Direction="";
                
                if(paddle2Direction =="up" && paddle2Y>0){
                    paddle2Y-=20;
                }
                else if(paddle2Direction=="down" && paddle2Y+50<800){
                    paddle2Y+=20;
                }
                
                paddle2Direction="";
                
                // paddle1 and  ball collision detection 
                if( paddle1X<ballX+radius && paddle1X+30>ballX-radius && paddle1Y<ballY+radius && paddle1Y+50>ballY-radius){
                    
                    collidePoint=ballY-(paddle1Y+25);
                    collidePoint=collidePoint/25;
                    angle=collidePoint*(Math.PI/4);
                    velocityX=Math.cos(angle)*speed;
                    velocityY=Math.sin(angle)*speed;
                    speed+=0.5;
                    
                }
                
                // paddle2 and  ball collision detection 
                if( paddle2X<ballX+radius && paddle2X+30>ballX-radius && paddle2Y<ballY+radius && paddle2Y+50>ballY-radius){
                    
                    collidePoint=ballY-(paddle2Y+25);
                    collidePoint=collidePoint/25;
                    angle=collidePoint*(Math.PI/4);
                    velocityX=-Math.cos(angle)*speed;
                    velocityY=Math.sin(angle)*speed;
                    speed+=0.5;
                    
                }
                
                // if ball hits boundary
                if(ballX-radius<=0 || ballX+radius>=1000){
                    startGame();
                    
                }
                
                if(ballY-radius<=0 || ballY+radius>=800){
                    velocityY=-velocityY;
                    
                }

                 // draw ball 
                context.setFill(Color.WHITE);
                context.fillOval(ballX,ballY,radius,radius);
                
                // draw paddle 1
                context.fillRect(paddle1X,paddle1Y,30,50);
                
                // draw paddle 2 
                context.fillRect(paddle2X,paddle2Y,30,50);
                
                // move ball 
                ballX+=velocityX;
                ballY+=velocityY;
            }
        },0,20); 
        
        // show stage
        primaryStage.setScene(scene);
	primaryStage.setTitle("Pong");
	primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

  
    
}
